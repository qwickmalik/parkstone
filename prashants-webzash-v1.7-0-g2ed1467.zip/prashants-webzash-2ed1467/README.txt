Webzash - Easy to use web based double entry accounting software
================================================================

http://webzash.org

Webzash is a web based double entry accouting software written in PHP - CodeIgniter and uses MySQL as database backend.

Webzash is licensed under Apache License, Version 2.0
http://www.apache.org/licenses/LICENSE-2.0

Features include
- No setup required
- Works on Shared Hosting environment
- Very easy to use
- Community driven
- Support for multiple accounts
- Support for colored tags
- Reports include balance sheet, profit and loss statement, trial balance, ledger statement

Note : Webzash includes works under other copyright notices and distributed according to the terms of their own licenses
