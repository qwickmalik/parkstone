<div>
	<div id="left-col">
		<div class="settings-container">
			<div class="settings-title">
				<?php echo anchor('report/balancesheet', 'Balance Sheet', array('title' => 'Balance Sheet')); ?>
			</div>
			<div class="settings-desc">
				&nbsp;
			</div>
		</div>
		<div class="settings-container">
			<div class="settings-title">
				<?php echo anchor('report/profitandloss', 'Profit and Loss Statement', array('title' => 'Profit and Loss Statement')); ?>
			</div>
			<div class="settings-desc">
				&nbsp;
			</div>
		</div>
		<div class="settings-container">
			<div class="settings-title">
				<?php echo anchor('report/trialbalance', 'Trial Balance', array('title' => 'Trial Balance')); ?>
			</div>
			<div class="settings-desc">
				&nbsp;
			</div>
		</div>
		<div class="settings-container">
			<div class="settings-title">
				<?php echo anchor('report/ledgerst', 'Ledger Statement', array('title' => 'Ledger Statement')); ?>
			</div>
			<div class="settings-desc">
				&nbsp;
			</div>
		</div>
	</div>
	<div id="right-col">

	</div>
</div>
<div class="clear">
</div>
