shortcut("Ctrl+H",
	function() {
		window.open(jsSiteUrl, "_self");
	},
	{
		'type': 'keydown',
		'propagate': false,
		'target': document
	}
);
